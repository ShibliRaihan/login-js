import React from 'react';
import { Link } from 'react-router-dom';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';

import { accountService, alertService } from '@/services';

function ForgotPassword() {
    const initialValues = {
        email: ''
    };

    const validationSchema = Yup.object().shape({
        email: Yup.string()
            .email('Email is invalid')
            .required('Email is required')
    });

    function onSubmit({ email }, { setSubmitting }) {
        alertService.clear();
        accountService.forgotPassword(email)
            .then(() => alertService.success('Please check your email for password reset instructions'))
            .catch(error => alertService.error(error))
            .finally(() => setSubmitting(false));
    }

    return (
        <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
            {({ errors, touched, isSubmitting }) => (
                <Form>
                    <h3 className="card-header border-0">Tailor Wine</h3>
                    <h4 className=''>
                        Please enter your email address and <br/>
                        we'll send you a link to reset your password.
                    </h4>

                    <div className="card-body">
                        <div className="form-group">
                            <label>Email address</label>
                            <div className='input-icons'>
                                <img src='https://i.postimg.cc/zGWKrgXv/email.png' className='email-icon'/>
                                <Field name="email" type="text" className={'form-control' + (errors.email && touched.email ? ' is-invalid' : '')} />
                            </div>
                            <ErrorMessage name="email" component="div" className="invalid-feedback" />
                        </div>
                        <div className="form-row">
                            <div className="form-group col-12">
                                <button type="submit" disabled={isSubmitting} className="btn btn-primary login_btn">
                                    {isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                                    Password reset
                                </button>
                            </div>
                            <div className="form-group col-12 text-center text-md-right ">
                                <Link to="login" className="btn btn-link backtologin">Back to Login</Link>
                            </div>
                        </div>
                    </div>
                </Form>
            )}
        </Formik>        
    )
}

export { ForgotPassword }; 