import React from 'react';
import { Link } from 'react-router-dom';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';

import { accountService, alertService } from '@/services';
import { func } from 'prop-types';

// import mailicon from '../img/email.png';
// import lockicon from '../img/lock.png';
// import eyeicon from '../img/visibility.png';


function Login({ history, location }) {
    const initialValues = {
        email: '',
        password: ''
    };

    const validationSchema = Yup.object().shape({
        email: Yup.string()
            .email('Email is invalid')
            .required('Email is required'),
        password: Yup.string().required('Password is required')
    });

    function onSubmit({ email, password }, { setSubmitting }) {
        alertService.clear();
        accountService.login(email, password)
            .then(() => {
                const { from } = location.state || { from: { pathname: "/" } };
                history.push(from);
            })
            .catch(error => {
                setSubmitting(false);
                alertService.error(error);
            });
    }

    const visibilityPassword = () =>{
        var passVisible = document.getElementById("password_visible");
        if (passVisible.type === "password") {
            passVisible.type = "text";
        } else {
            passVisible.type = "password";
        }
    }  

    return ( 
        <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
            {({ errors, touched, isSubmitting }) => (
                <Form className='login_form'>
                    <h3 className="card-header border-0">Tailor Wine</h3>
                    <h4>Please login to access to the dashboard</h4>
                    <div className="card-body">
                        <div className="form-group">
                            <label>Email address</label>
                            <div className='input-icons'>
                                <img src='https://i.postimg.cc/zGWKrgXv/email.png' className='email-icon'/>
                                <Field name="email" type="text" className={'form-control' + (errors.email && touched.email ? ' is-invalid' : '')} />
                            </div>                            
                            <ErrorMessage name="email" component="div" className="invalid-feedback" />
                        </div>
                        <div className="form-group">
                            <label>Password</label>
                            <div className='input-icons'>
                                <img src="https://i.postimg.cc/wB2tqcKq/lock.png" alt="" className='lock-icon'/>
                                    <Field name="password" type="password"  id="password_visible" className={'form-control' + (errors.password && touched.password ? ' is-invalid' : '')} />
                                <img src="https://i.postimg.cc/PNnfzPGV/visibility.png" alt=""  className='visibility-icon' onClick={visibilityPassword}/>
                            </div>                            
                            <ErrorMessage name="password" component="div" className="invalid-feedback" />
                        </div>
                        <div className="form-row">
                            <div className="form-group col-12">
                                <button type="submit" disabled={isSubmitting} className="btn btn-primary login_btn">
                                    {isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                                    Login
                                </button>
                            </div>
                            <div className="form-group col text-md-right text-center col-12 pass_forgot">
                                <span className='password_forgotten'>Password Forgotten ?</span>  <Link to="forgot-password" className="btn btn-link pr-0 password_recovery_link">Password recovery</Link>
                            </div>
                        </div>
                    </div>
                </Form>
            )}
        </Formik>
    )
}

export { Login }; 