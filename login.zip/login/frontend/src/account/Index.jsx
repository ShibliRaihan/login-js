import React, { useEffect } from 'react';
import { Route, Switch } from 'react-router-dom';

import { accountService } from '@/services';

import { Login } from './Login';
import { ForgotPassword } from './ForgotPassword';
import { ResetPassword } from './ResetPassword';


function Account({ history, match }) {
    const { path } = match;

    useEffect(() => {
        // redirect to home if already logged in
        if (accountService.userValue) {
            history.push('/');
        }
    }, []);

    return (
        <div className='login-form-wrap'>
        
            <div className="container h-100">
                <div className="row h-100">
                    <div className="col-sm-8 offset-sm-2 mt-5 h-100">
                        <div className="card">
                            <Switch>
                                <Route path={`${path}/login`} component={Login} />
                                <Route path={`${path}/forgot-password`} component={ForgotPassword} />
                                <Route path={`${path}/reset-password`} component={ResetPassword} />
                            </Switch>
                        </div>
                    </div>
                </div>
            </div>
            <div className='reserved-tetx'>Ⓒ 2022. All rights reserved.</div>
        </div>
    );
}

export { Account };