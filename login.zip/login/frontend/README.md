# react-signup-verification-boilerplate

React - Email Sign Up with Verification, Authentication & Forgot Password
