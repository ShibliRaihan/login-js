# node-mysql-signup-verification-api

NodeJS + MySQL - Boilerplate API with Email Sign Up, Verification, Authentication & Forgot Password
